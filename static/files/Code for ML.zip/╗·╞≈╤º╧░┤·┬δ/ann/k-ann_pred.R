### artificial neural network model ###
library(nnet)
library(Metrics)

# change the ## filepath ## into the real file path
data1 <- read.csv("## filepath ##\\k.csv", encoding = "UTF-8")
str(data1)


data <- data1[,-c(1)]
LLL <- dim(data)[2]
l <- dim(data)[1]



# change the ## filepath ## into the real file path
feature <- read.csv("## filepath ##\\feature_k.csv", encoding = "UTF-8")
names(feature)[1] <- "feature"
L <- dim(feature)[1]


# change the ## filepath ## into the real file path
para <- read.csv("## filepath ##\\ann_para.csv", encoding = "UTF-8")
str(para)


# create the output matrices
pred <- matrix(0, nrow = l, ncol = 1000)


b = 5 # 31 is the best (formula_31: Temperature~ML+na+d+fepa; formula_56: Temperature~ML+d+fepa)
a = 1

for (a in c(1:1000)){
  set.seed(a)
  par <- sample(2, nrow(data),replace = TRUE, prob = c(0.7,0.3))
  train <- data[par==1,]
  test <- data[par==2,]
  
  # formula：Temperature ~ features
  "formula" = as.character(feature[b,1])
  formula <- as.formula(formula)
  
  # optimized hyperparameters
  decay = para[b,2]
  size = para[b,3]
  
  set.seed(a)
  ann1=nnet(formula, data = train, maxit=3000,
            size=size, decay=decay, linout=T, trace=F)
  # help(nnet)
  # summary(ann1)
  
  # prediction of the testing set (did not involve in the current model training)
  p <- predict(ann1, test)
  pp <- as.matrix(p)
  k=1
  for (k in c(1:l)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] = NA}
    
    k = k+1
  }
  
  a = a+1
}

ad <- "## filepath ##\\"                      # change the ##output file path## into the real output file path

write.csv(pred, paste(ad, "ann_k_pred", b, ".csv"))



### hyperparameter optimization of artificial neural network model ###
library(nnet)
library(Metrics)

# change the ## filepath ## into the real file path
data1 <- read.csv("## filepath ##\\k.csv", encoding = "UTF-8")
str(data1)

data <- data1[,-c(1)]
LLL <- dim(data)[2]

# change the ## filepath ## into the real file path
feature <- read.csv("## filepath ##\\feature_k.csv", encoding = "UTF-8")
names(feature)[1] <- "feature"
L <- dim(feature)[1]


decay_r <- c(6:15) 

# grid search method + 10 fold cross-validation
t = 1
tt = 1
decay = 6
size = 8

for (tt in c(1:30)){
  for (decay in decay_r){
    # create the output matrices
    rmse_train <- matrix(0, nrow = L, ncol = 10)   
    r2_train <- matrix(0, nrow = L, ncol = 10)
    rmse_test <- matrix(0, nrow = L, ncol = 10)
    r2_test <- matrix(0, nrow = L, ncol = 10)
    
    aver1_tr <- matrix(0, nrow = L, ncol = 20)    
    aver2_tr <- matrix(0, nrow = L, ncol = 20)
    aver1_te <- matrix(0, nrow = L, ncol = 20)
    aver2_te <- matrix(0, nrow = L, ncol = 20)
    for (size in c(8:26)){  
      s_col = size - 7
      b = 1
      for (b in c(1:L)){ 
        for (t in c(1:10)){
          set.seed(tt)
          par1 <- sample(2, nrow(data),replace = TRUE, prob = c(0.7,0.3))
          train1 <- data[par1==1,]
          test1 <- data[par1==2,]
          
          par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
          train <- train1[par != t,]
          test <- train1[par == t,]
          
          # formula：k ~ features
          "formula" = as.character(feature[b,1])
          formula <- as.formula(formula)

          # modeling
          set.seed(tt)
          ann1=nnet(formula, data = train, maxit=3000,
                    size=size, decay=decay, linout=T, trace=F)
          # help(nnet)
          # summary(ann1)
          

          ### training and testing results ###
          ptrain <- predict(ann1, train)
          rmse_train[b,t] <- rmse(train$k,ptrain)           # RMSE of the training data set
          
          R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
          R2a[,1] <- ptrain
          R2a[,2] <- train$k                                                     
          R2a <- as.data.frame(R2a)
          names(R2a)[1] <- "ptrain"
          names(R2a)[2] <- "k"                                                   
          la <- lm(k~.,R2a)                                                      
          r2_train[b,t] <- as.numeric(summary(la)["r.squared"])       # R2 of the training data set
          

          ptest <- predict(ann1, test)
          rmse_test[b,t] <- rmse(test$k,ptest)              # RMSE of the testing data set
          
          R2b <- matrix(0, nrow = length(ptest), ncol = 2)
          R2b[,1] <- ptest
          R2b[,2] <- test$k                                                     
          R2b <- as.data.frame(R2b)
          names(R2b)[1] <- "ptest"
          names(R2b)[2] <- "k"                                                  
          lb <- lm(k~.,R2b)                                                      
          r2_test[b,t] <- as.numeric(summary(lb)["r.squared"])         # R2 of the testing data set
          
          
          aver1_tr[b,s_col] = mean(rmse_train[b,])
          aver2_tr[b,s_col] = mean(r2_train[b,])
          aver1_te[b,s_col] = mean(rmse_test[b,])
          aver2_te[b,s_col] = mean(r2_test[b,])
          
          
          t = t + 1
        }
        b = b + 1
      }
      
      
      
      ad <- "## filepath ##\\results\\"                      # change the ##output file path## into the real output file path
      
      write.csv(aver1_tr,paste(ad,tt, decay, "aver1_tr.csv"))
      write.csv(aver2_tr,paste(ad,tt, decay, "aver2_tr.csv"))
      write.csv(aver1_te,paste(ad,tt, decay, "aver1_te.csv"))
      write.csv(aver2_te,paste(ad,tt, decay, "aver2_te.csv"))
      
    }
  }
}


### Further processing was done by EXCEL.



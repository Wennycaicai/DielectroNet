# Gradient Boosting Decision Tree
# install.packages('gbm')
library(gbm)  
library(Metrics)

# change the ## filepath ## into the real file path
data <- read.csv("## filepath ##\\TCk.csv", encoding = "UTF-8")
str(data)

feature <- read.csv("## filepath ##\\feature_TCk.csv", encoding = "UTF-8")
names(feature)[1] <- "feature"
L <- dim(feature)[1]

para <- read.csv("## filepath ##\\gbdt_para.csv", encoding = "UTF-8")
str(para)


rmse_train <- matrix(0, nrow = L, ncol = 1000)
r2_train <- matrix(0, nrow = L, ncol = 1000)
rmse_test <- matrix(0, nrow = L, ncol = 1000)
r2_test <- matrix(0, nrow = L, ncol = 1000)

b = 61
a = 1
for (b in c(1:L)){
  for (a in c(1:1000)){
    
    set.seed(a)
    par <- sample(2, nrow(data),replace = TRUE, prob = c(0.7,0.3))
    train <- data[par==1,]
    test <- data[par==2,]
    
    
    shrinkage = para[b,2]
    ntree = para[b,3]
    

    # formula：TCk ~ features
    "formula" = as.character(feature[b,1])
    formula <- as.formula(formula)
    LL <- length(strsplit(as.character(feature[b,1]), "\\+")[[1]])
    
    set.seed(a)
    gbm1 <- gbm(formula, data=train,                                                                           
                var.monotone= rep(0,LL),    
                distribution="gaussian",        
                n.trees=ntree,                    
                shrinkage=shrinkage,                   
                interaction.depth=3,             
                bag.fraction = 0.5,              
                train.fraction = 0.5,          
                n.minobsinnode = 10,            
                keep.data=TRUE,                 
                verbose=FALSE,                  
                n.cores=2)                      
    

    ptrain <- predict(gbm1, train)
    rmse_train[b,a] <- rmse(train$TCk,ptrain)            
    
    R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
    R2a[,1] <- ptrain
    R2a[,2] <- train$TCk                                                 
    R2a <- as.data.frame(R2a)
    names(R2a)[1] <- "ptrain"
    names(R2a)[2] <- "TCk"                                                
    la <- lm(TCk~.,R2a)                                                   
    r2_train[b,a] <- as.numeric(summary(la)["r.squared"])
    

    ptest <- predict(gbm1, test)
    rmse_test[b,a] <- rmse(test$TCk,ptest)                   
    
    R2b <- matrix(0, nrow = length(ptest), ncol = 2)
    R2b[,1] <- ptest
    R2b[,2] <- test$TCk                                                     
    R2b <- as.data.frame(R2b)
    names(R2b)[1] <- "ptest"
    names(R2b)[2] <- "TCk"                                                  
    lb <- lm(TCk~.,R2b)                                                    
    r2_test[b,a] <- as.numeric(summary(lb)["r.squared"])
    
    
    a = a+1
  }
  a = 1
  b = b+1
  
}

ad <- "## filepath ##\\results_optimal\\"                      # change the ##output file path## into the real output file path

write.csv(rmse_train,paste(ad, "rmse_train.csv"))
write.csv(r2_train,paste(ad, "r2_train.csv"))
write.csv(rmse_test,paste(ad, "rmse_test.csv"))
write.csv(r2_test,paste(ad, "r2_test.csv"))





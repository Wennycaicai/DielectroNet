# Gradient Boosting Decision Tree
# install.packages('gbm')
library(gbm)  
library(Metrics)

data1 <- read.csv("## filepath ##\\k.csv", encoding = "UTF-8")
str(data1)


data <- data1[,-c(1)]
LLL <- dim(data)[2]
l <- dim(data)[1]



# change the ## filepath ## into the real file path
feature <- read.csv("## filepath ##\\feature_k.csv", encoding = "UTF-8")
names(feature)[1] <- "feature"
L <- dim(feature)[1]


para <- read.csv("## filepath ##\\gbdt_para.csv", encoding = "UTF-8")
str(para)


# create the output matrices
pred <- matrix(0, nrow = l, ncol = 1000)

b = 57
a = 1

for (a in c(1:1000)){
  # 训练集测试集
  set.seed(a)
  par <- sample(2, nrow(data),replace = TRUE, prob = c(0.7,0.3))
  train <- data[par==1,]
  test <- data[par==2,]

  

  shrinkage = para[b,2]
  ntree = para[b,3]
  

  # fit initial model  
  # formula：k ~ features
  "formula" = as.character(feature[b,1])
  formula <- as.formula(formula)
  LL <- length(strsplit(as.character(feature[b,1]), "\\+")[[1]])
  
  set.seed(a)
  gbm1 <- gbm(formula, data=train,                                                                             
              var.monotone= rep(0,LL),    
              distribution="gaussian",        
              n.trees=ntree,                     
              shrinkage=shrinkage,             
              interaction.depth=3,              
              bag.fraction = 0.5,             
              train.fraction = 0.5,             
              n.minobsinnode = 10,             
              keep.data=TRUE,                 
              verbose=FALSE,                  
              n.cores=2)                      
  

  # prediction of the testing set (did not involve in the current model training)
  p <- predict(gbm1, test)
  pp <- data.frame(p, row.names = row.names(test))
  pp <- as.matrix(pp)
  k=1
  for (k in c(1:l)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] = NA}
    
    k = k+1
  }
  
  a = a+1
}

ad <- "## filepath ##\\"                      # change the ##output file path## into the real output file path

write.csv(pred, paste(ad, "gbdt_k_pred", b, ".csv"))







### linear model ###
library(Metrics)

# change the ## filepath ## into the real file path
data1 <- read.csv("## filepath ##\\TCk.csv", encoding = "UTF-8")
str(data1)

data <- data1[,-c(1)]
LLL <- dim(data)[2]
l <- dim(data)[1]


# change the ## filepath ## into the real file path
feature <- read.csv("## filepath ##\\feature_TCk.csv", encoding = "UTF-8")
names(feature)[1] <- "feature"
L <- dim(feature)[1]


# create the output matrices
pred <- matrix(0, nrow = l, ncol = 1000)

# The best feature combination b = 31
b = 14
a = 1

for (a in c(1:1000)){
  set.seed(a)
  par <- sample(2, nrow(data),replace = TRUE, prob = c(0.7,0.3))
  train <- data[par==1,]
  test <- data[par==2,]
  
  # formula：Temperature ~ features
  "formula" = as.character(feature[b,1])
  formula <- as.formula(formula)
  

  # modeling
  set.seed(a)
  lr <- lm(formula, train)
  # summary(lr)
  # plot(lr)
  
  
  # prediction of the testing set (did not involve in the current model training)
  p <- predict(lr, test)
  pp <- as.matrix(p)
  k=1
  for (k in c(1:l)){
    if (k %in% row.names(pp)) {pred[k,a] = pp[row.names(pp) == k]}
    else {pred[k,a] = NA}
    
    k = k+1
  }
  

  a = a+1
}

ad <- "D:\\QJC\\ML\\lr - TCk\\results\\"                      # change the ##output file path## into the real output file path

write.csv(pred, paste(ad, "lr_TCk_pred", b, ".csv", sep=""))

### Further processing was done by EXCEL.




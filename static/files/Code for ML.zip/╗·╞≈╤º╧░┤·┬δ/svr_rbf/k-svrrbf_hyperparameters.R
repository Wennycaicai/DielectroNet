### hyperparameter optimization of support vector regression (with radial basis function as kernel) model ###

library(Metrics)
library(e1071)

# change the ## filepath ## into the real file path
data1 <- read.csv("## filepath ##\\k.csv", encoding = "UTF-8")
str(data1)

data <- data1[,-c(1)]
LLL <- dim(data)[2]


# change the ## filepath ## into the real file path
feature <- read.csv("## filepath ##\\feature_k.csv", encoding = "UTF-8")
names(feature)[1] <- "feature"
L <- dim(feature)[1]


# create the output matrices
rmse_train <- matrix(0, nrow = L, ncol = 10) 
r2_train <- matrix(0, nrow = L, ncol = 10)
rmse_test <- matrix(0, nrow = L, ncol = 10)
r2_test <- matrix(0, nrow = L, ncol = 10)

aver1_tr <- matrix(0, nrow = L, ncol = 10)   
aver2_tr <- matrix(0, nrow = L, ncol = 10)
aver1_te <- matrix(0, nrow = L, ncol = 10)
aver2_te <- matrix(0, nrow = L, ncol = 10)

tt = 1
gamma = 0.06
cost = 2^-5

range_gamma = seq(0.05,0.8,0.05)
range_cost = c(2^-5, 2^-4, 2^-3, 2^-2, 2^-1, 1, 2^1, 2^2, 2^3, 2^4)



for (gamma in range_gamma){
  ad <- paste("## filepath ##\\cv_results\\", gamma, "\\", sep = "") 
  dir.create(ad)
  name_dir = c(" aver1_tr", " aver2_tr", " aver1_te", " aver2_te")
  for (ndir in name_dir){
    ad <- paste("## filepath ##\\cv_results\\", gamma, "\\", gamma, sep = "")
    dir.create(paste(ad, ndir, sep = ""))
  }
}





# grid search method + 10 fold cross-validation
for (tt in c(1:30)){
  for (gamma in range_gamma){
    for (cost in range_cost){
      b = 1
      t= 1
      for (b in c(1:L)){
        for (t in c(1:10)){
          set.seed(tt)
          par1 <- sample(2, nrow(data),replace = TRUE, prob = c(0.7,0.3))
          train1 <- data[par1==1,]
          test1 <- data[par1==2,]
          
          par <- sample(10, nrow(train1),replace = TRUE, prob = rep(0.1,10))
          train <- train1[par != t,]
          test <- train1[par == t,]
          
  
          # formula：k ~ features
          "formula" = as.character(feature[b,1])
          formula <- as.formula(formula)
          
          # modeling
          set.seed(tt)
          svr <- svm(formula, train, gamma = gamma, cost = cost, 
                       kernel ="radial")  # linear/radial/polynomial
          
          # svr <- svm(formula, train, kernel ="radial")  # linear/radial/polynomial
          # summary(svr)
          # help(svm)
          
          
          ### training and testing results ###
          ptrain <- predict(svr, train)
          rmse_train[b,t] <- rmse(train$k,ptrain)           # RMSE of the training data set
          
          R2a <- matrix(0, nrow = length(ptrain), ncol = 2)
          R2a[,1] <- ptrain
          R2a[,2] <- train$k
          R2a <- as.data.frame(R2a)
          names(R2a)[1] <- "ptrain"
          names(R2a)[2] <- "k"
          la <- lm(k~.,R2a)
          r2_train[b,t] <- as.numeric(summary(la)["r.squared"])       # R2 of the training data set
          
          ptest <- predict(svr, test)
          rmse_test[b,t] <- rmse(test$k,ptest)              # RMSE of the testing data set
          
          R2b <- matrix(0, nrow = length(ptest), ncol = 2)
          R2b[,1] <- ptest
          R2b[,2] <- test$k
          R2b <- as.data.frame(R2b)
          names(R2b)[1] <- "ptest"
          names(R2b)[2] <- "k"
          lb <- lm(k~.,R2b)
          r2_test[b,t] <- as.numeric(summary(lb)["r.squared"])         # R2 of the testing data set
          
          aver1_tr[b,log2(cost)+6] = mean(rmse_train[b,])
          aver2_tr[b,log2(cost)+6] = mean(r2_train[b,])
          aver1_te[b,log2(cost)+6] = mean(rmse_test[b,])
          aver2_te[b,log2(cost)+6] = mean(r2_test[b,])
          
          t = t + 1
      }
        
    b = b+1
    print(paste("已完成:", b))
  }
  
      ad <- paste("## filepath ##\\cv_results\\", gamma, "\\", gamma, sep = "")  # change the ##output file path## into the real output file path
      
      write.csv(aver1_tr,paste(ad," aver1_tr\\", tt, " ", gamma," aver1_tr.csv", sep = ""))
      write.csv(aver2_tr,paste(ad," aver2_tr\\", tt, " ", gamma," aver2_tr.csv", sep = ""))
      write.csv(aver1_te,paste(ad," aver1_te\\", tt, " ", gamma," aver1_te.csv", sep = ""))
      write.csv(aver2_te,paste(ad," aver2_te\\", tt, " ", gamma," aver2_te.csv", sep = ""))

    }
  }
}


### Further processing was done by EXCEL.




